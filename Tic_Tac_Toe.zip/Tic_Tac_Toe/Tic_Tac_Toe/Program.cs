﻿using System;

class Program
{
    static char[,] board = new char[3, 3];

    static void InitializeBoard()
    {
        for (int row = 0; row < 3; row++)
        {
            for (int col = 0; col < 3; col++)
            {
                board[row, col] = ' ';
            }
        }
    }

    static void DisplayBoard()
    {
        Console.WriteLine("  0 1 2");

        for (int row = 0; row < 3; row++)
        {
            Console.Write(row + " ");

            for (int col = 0; col < 3; col++)
            {
                Console.Write(board[row, col] + " ");
            }

            Console.WriteLine();
        }
    }

    static bool IsMoveValid(int row, int col)
    {
        return row >= 0 && row < 3 && col >= 0 && col < 3 && board[row, col] == ' ';
    }

    static bool IsGameOver()
    {
        for (int i = 0; i < 3; i++)
        {
            if (board[i, 0] != ' ' && board[i, 0] == board[i, 1] && board[i, 1] == board[i, 2])
            {
                Console.WriteLine($"Player {(board[i, 0] == 'X' ? 1 : 2)} wins!");
                return true;
            }

            if (board[0, i] != ' ' && board[0, i] == board[1, i] && board[1, i] == board[2, i])
            {
                Console.WriteLine($"Player {(board[0, i] == 'X' ? 1 : 2)} wins!");
                return true;
            }
        }

        if (board[0, 0] != ' ' && board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2])
        {
            Console.WriteLine($"Player {(board[0, 0] == 'X' ? 1 : 2)} wins!");
            return true;
        }

        if (board[0, 2] != ' ' && board[0, 2] == board[1, 1] && board[1, 1] == board[2, 0])
        {
            Console.WriteLine($"Player {(board[0, 2] == 'X' ? 1 : 2)} wins!");
            return true;
        }

        for (int row = 0; row < 3; row++)
        {
            for (int col = 0; col < 3; col++)
            {
                if (board[row, col] == ' ')
                    return false;
            }
        }

        Console.WriteLine("It's a tie!");
        return true;
    }

    static void Main(string[] args)
    {
        InitializeBoard();
        bool player1Turn = true;

        while (!IsGameOver())
        {
            DisplayBoard();
            Console.WriteLine($"Player {(player1Turn ? 1 : 2)}, enter your move (row column):");
            string[] input = Console.ReadLine().Split();
            
            if (input.Length != 2 || !int.TryParse(input[0], out int row) || !int.TryParse(input[1], out int col))
            {
                Console.WriteLine("Invalid input. Please enter row and column (e.g., 1 2).");
                continue;
            }

            if (IsMoveValid(row, col))
            {
                board[row, col] = player1Turn ? 'X' : 'O';
                player1Turn = !player1Turn;
            }

            else
            {
                Console.WriteLine("Invalid move. Try again.");
            }
        }

        DisplayBoard();
        Console.WriteLine("Game over! Press Enter to exit.");
        Console.ReadLine();
    }
}
